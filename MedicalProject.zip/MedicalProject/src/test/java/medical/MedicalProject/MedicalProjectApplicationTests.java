package medical.MedicalProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MedicalProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
